﻿using System;
using System.Web;
using System.Web.UI;

namespace Tour_Management
{
    public partial class MainProfilePage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //  Use the correct session variable from login page
                if (Session["UserEmail"] != null)
                {
                    Label1.Text = "Welcome, " + Session["UserEmail"].ToString();
                }
                else
                {
                    Response.Redirect("userlogin.aspx");
                }
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            // Clear all session data
            Session.Clear();
            Session.Abandon();

            //  Clear authentication cookie if used
            if (Request.Cookies[".ASPXAUTH"] != null)
            {
                var cookie = new HttpCookie(".ASPXAUTH");
                cookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(cookie);
            }

            //  Redirect to login page
            Response.Redirect("userlogin.aspx");
        }
    }
}
