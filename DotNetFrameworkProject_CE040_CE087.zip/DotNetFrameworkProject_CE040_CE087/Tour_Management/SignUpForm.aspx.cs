﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

namespace Tour_Management
{
    public partial class SignUpForm : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString))
                {
                    conn.Open();

                    // Check if email already exists before inserting
                    string checkQuery = "SELECT COUNT(*) FROM UserInfo WHERE Email = @Email";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Email", email.Text.Trim());
                        int existingCount = (int)checkCmd.ExecuteScalar();

                        if (existingCount > 0)
                        {
                            // Email already registered
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('⚠️ This email is already registered. Please log in or use a different email.');", true);
                            return;
                        }
                    }

                    // Insert new user
                    string insertQuery = @"INSERT INTO UserInfo
                        (Email, FirstName, LastName, Gender, Password, dob, Street, City, State)
                        VALUES(@Email, @FirstName, @LastName, @Gender, @Password, @dob, @Street, @City, @State)";
                    using (SqlCommand com = new SqlCommand(insertQuery, conn))
                    {
                        com.Parameters.AddWithValue("@Email", email.Text.Trim());
                        com.Parameters.AddWithValue("@FirstName", fname.Text.Trim());
                        com.Parameters.AddWithValue("@LastName", lname.Text.Trim());
                        com.Parameters.AddWithValue("@Gender", gender.Text.Trim());
                        com.Parameters.AddWithValue("@Password", password1.Text.Trim());
                        com.Parameters.AddWithValue("@dob", dob.Text.Trim());
                        com.Parameters.AddWithValue("@Street", street.Text.Trim());
                        com.Parameters.AddWithValue("@City", city.Text.Trim());
                        com.Parameters.AddWithValue("@State", state.Text.Trim());

                        com.ExecuteNonQuery();
                    }

                    // Show success alert and redirect
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' Registration Successful! Redirecting to login page...'); window.location='userlogin.aspx';", true);
                }
            }
            catch (SqlException ex)
            {
                // Handle SQL-specific errors
                if (ex.Number == 2627 || ex.Number == 2601)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' This email is already registered. Please use a different one.');", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' Database error occurred. Please try again later.');", true);
                }
            }
            catch (Exception)
            {
                // Handle general errors
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' Something went wrong. Please check your input and try again.');", true);
            }
        }
    }
}
