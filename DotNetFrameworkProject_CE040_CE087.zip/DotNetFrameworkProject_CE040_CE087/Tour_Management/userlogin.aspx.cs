﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

namespace Tour_Management
{
    public partial class userlogin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btn_Submit(object sender, EventArgs e)
        {
            string emailInput = txtEmail.Text.Trim();
            string passwordInput = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(emailInput) || string.IsNullOrEmpty(passwordInput))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' Please enter both Email and Password.');", true);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString))
                {
                    conn.Open();
                    string query = "SELECT Password FROM UserInfo WHERE Email = @Email";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", emailInput);

                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            string storedPassword = result.ToString();

                            if (storedPassword == passwordInput)
                            {
                                //  Successful login — redirect directly
                                Session["UserEmail"] = emailInput;
                                Response.Redirect("MainProfilePage.aspx", false);
                                Context.ApplicationInstance.CompleteRequest();
                                return;
                            }
                            else
                            {
                                //  Wrong password
                                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' Incorrect password. Please try again.');", true);
                            }
                        }
                        else
                        {
                            //  Email not found
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(' No account found with this email. Please sign up first.');", true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = ex.Message.Replace("'", "");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", $"alert(' An error occurred: {message}');", true);
            }
        }

        protected void Btn_reg(object sender, EventArgs e)
        {
            Response.Redirect("SignUpForm.aspx");
        }
    }
}
